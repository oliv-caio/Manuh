﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Manuh.Models;
using MySql.Data.MySqlClient;

namespace Manuh.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Hist()
        {
            return View();
        }
        public IActionResult Delivery()
        {
            return View();
        }
        public IActionResult Excluir(int id)
        {
            using (MySqlConnection conn = new MySqlConnection("Server=localhost;Port=3306;Database=bancomanuh;Uid=root;Pwd=root;"))
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand("DELETE FROM cliente WHERE idcliente = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }
            }

            return View();
        }

        public IActionResult Editar(int id)
        {
            ClientePedido cliente = null;
            using (MySqlConnection conn = new MySqlConnection("Server=localhost;Port=3306;Database=bancomanuh;Uid=root;Pwd=root;"))
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand("SELECT a.idcliente, a.nomecliente, a.email, a.telefonepessoal, a.nomerua, b.idpedido, b.idprato FROM cliente a, pedido b WHERE a.idcliente = b.idcliente", conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {

                        if (reader.Read())
                        {
                            cliente = new ClientePedido();
                            cliente.IdCliente = reader.GetInt32(0);
                            cliente.Nome = reader.GetString(1);
                            cliente.Email = reader.GetString(2);
                            cliente.Tel = reader.GetInt32(3);
                            cliente.End = reader.GetString(4);
                            cliente.IdPrato = reader.GetInt32(6);

                        }

                        else
                        {
                            throw new Exception("Cliente não endontrado!");
                        }

                    }

                }
            }
            return View(cliente);
        }

        [HttpPost]
        public IActionResult Salvar([FromForm] ClientePedido c)
        {
            if (c == null ||
                c.Nome == null ||
                c.End == null)
            {
                throw new Exception("Dados Invalidos!");
            }
            using (MySqlConnection conn = new MySqlConnection("Server=localhost;Port=3306;Database=bancomanuh;Uid=root;Pwd=root;"))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO cliente (nomecliente, telefonepessoal, nomerua, email) VALUES (@nomecliente, @telefonepessoal, @nomerua, @email)", conn))
                {


                    cmd.Parameters.AddWithValue("@nomecliente", c.Nome);
                    cmd.Parameters.AddWithValue("@telefonepessoal", c.Tel);
                    cmd.Parameters.AddWithValue("@nomerua", c.End);
                    cmd.Parameters.AddWithValue("@email", c.Email);

                    cmd.ExecuteNonQuery();
                }

                using (MySqlCommand cmd = new MySqlCommand("SELECT last_insert_id()", conn))
                {
                    c.IdCliente = (int)((ulong)cmd.ExecuteScalar());
                }

                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO pedido (idcliente, idprato) VALUES (@idcliente, @idprato)", conn))
                {


                    cmd.Parameters.AddWithValue("@idcliente", c.IdCliente);
                    cmd.Parameters.AddWithValue("@idprato", c.IdPrato);

                    cmd.ExecuteNonQuery();
                }
                return Redirect("/Home/Index");
            }
        }

        public IActionResult Pedido()
        {
            List<ClientePedido> lista = new List<ClientePedido>();

            using (MySqlConnection conn = new MySqlConnection("Server=localhost;Port=3306;Database=bancomanuh;Uid=root;Pwd=root;"))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("SELECT a.idcliente, a.nomecliente, a.email, a.telefonepessoal, a.nomerua, b.idpedido, b.idprato FROM cliente a, pedido b WHERE a.idcliente = b.idcliente", conn))
                {

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            ClientePedido cliente = new ClientePedido();
                            Pedido p = new Pedido(); 
                            cliente.IdCliente = reader.GetInt32(0);
                            cliente.Nome = reader.GetString(1);
                            cliente.Tel = reader.GetInt32(3);
                            cliente.End = reader.GetString(4);
                            cliente.Email = reader.GetString(2);
                            cliente.IdPedido = reader.GetInt32(5);
                            cliente.IdPrato = reader.GetInt32(6);
                            lista.Add(cliente);

                        }
                    }
                }

                return View(lista);
            }
        }

        [HttpPost]
        public IActionResult SalvarPedido([FromForm] ClientePedido c)
        {
            if (c == null ||
                c.Nome == null ||
                c.End == null)
            {
                throw new Exception("Dados Invalidos!");
            }
            using (MySqlConnection conn = new MySqlConnection("Server=localhost;Port=3306;Database=bancomanuh;Uid=root;Pwd=root;"))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO cliente (nomecliente, telefonepessoal, nomerua, email) VALUES (@nomecliente, @telefonepessoal, @nomerua, @email)", conn))
                {
                    cmd.Parameters.AddWithValue("@nomecliente", c.Nome);
                    cmd.Parameters.AddWithValue("@telefonepessoal", c.Tel);
                    cmd.Parameters.AddWithValue("@nomerua", c.End);
                    cmd.Parameters.AddWithValue("@email", c.Email);

                    cmd.ExecuteNonQuery();
                }
                using (MySqlCommand cmd = new MySqlCommand("SELECT last_insert_id()", conn))
                {
                    c.IdCliente = (int)((ulong)cmd.ExecuteScalar());
                }
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO pedido (idprato, idcliente) VALUES (@idprato, @idcliente)", conn))
                {
                    cmd.Parameters.AddWithValue("@idprato", c.IdPrato);
                    cmd.Parameters.AddWithValue("@idcliente", c.IdCliente);

                    cmd.ExecuteNonQuery();
                }
                return Redirect("/Home/Index");
            }
        }
    }
}

