using System;

namespace Manuh.Models
{
    public class Bebida
    {
     
        public int Id {get; set;}
        public String Nome {get; set;}
        public int Valor {get; set;}

    }
}