using System;

namespace Manuh.Models
{
    public class ClientePedido
    {
        public int IdPedido { get; set; }
        public int IdPrato { get; set; }
        public int IdBedida { get; set; }
        public int IdCliente { get; set; }
        public string Nome { get; set; }
        public int Tel { get; set; }
        public string End { get; set; }
        public string Email { get; set; }

    }
}