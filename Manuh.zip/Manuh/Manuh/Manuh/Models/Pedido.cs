using System;

namespace Manuh.Models
{
    public class Pedido
    {
     
        public int IdPedido {get; set;}
        public int IdPrato {get; set;}
        public int IdBedida {get; set;}

    }
}