using System;

namespace Manuh.Models
{
    public class Pratos
    {
     
        public int IdPrato {get; set;}
        public int Valor {get; set;}

    }
}