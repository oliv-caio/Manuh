using System;

namespace Manuh.Models
{
    public class Cliente
    {
     
        public int Id {get; set;}
        public string Nome {get; set;}
        public int Tel {get; set;}
        public string End {get; set;}
        public string Email { get; set; }

    }
}